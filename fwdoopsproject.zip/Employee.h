#ifndef EMPLOYEE_H_INCLUDED
#define EMPLOYEE_H_INCLUDED

#include <iostream>
#include <string.h>
#include <fstream>
#include "Person.h"

using namespace std;


class Employee:public Person
{
    int e_id;
    int d_id;

public:

    Employee(int eid=0,int did=0)
    {
        e_id=eid;
        d_id=did;

    }
    char* get_name()
    {
        return name;
    }

    char* get_password()
    {
        return password;
    }

    int get_e_id()
    {
        return e_id;
    }

    int get_d_id()
    {
        return d_id;
    }

    void show()
    {
        cout<<name;
        cout<<password;
    }

    friend ostream &operator<<( ostream &, const Employee & );
    friend istream &operator>>( istream &, Employee & );
};

// overloaded stream extraction operator; cannot be
// a member function if we would like to invoke it with
// cin >> someEmployee;
istream &operator>>( istream &input, Employee &emp )
{
    cout<<"Enter Employee Details.....\n";
    cout<<"ID:";
    input >> emp.e_id;
    cout<<"Name:";
    input >> emp.name;
    cout<<"Password:";
    input >> emp.password;
    cout<<"Department ID:";
    input >> emp.d_id;
    cout<<"Address:";
    input >> emp.add;
    cout<<"Email:";
    input >> emp.email;
    cout<<"Gender:";
    input >> emp.gender;
    cout<<"Phone Number:";
    input >> emp.phn;
    cout<<"Date Of Birth:";
    input >> emp.dob;
    cout<<"Age:";
    input >> emp.age;
    return input; // enables cin >> a >> b >> c;

} // end function operator>>


// overloaded stream insertion operator; cannot be
// a member function if we would like to invoke it with
// cout << someEmployee;
ostream &operator<<( ostream &output, const Employee &emp )
{
    cout<<"Employee Details.....\n";
    output << "ID:"<<emp.e_id<<"\n";
    output << "Name:"<<emp.name<<"\n";
    output << "Password:"<<emp.password<<"\n";
    output << "Department ID:"<<emp.d_id<<"\n";
    output << "Address:"<<emp.add<<"\n";
    output << "Email:"<<emp.email<<"\n";
    output << "Gender:"<<emp.gender<<"\n";
    output << "Phone Number:"<<emp.phn<<"\n";
    output << "Date Of Birth:"<<emp.dob<<"\n";
    output << "Age:"<<emp.age<<"\n";

    return output;     // enables cout << a << b << c;

} // end function operator<<


void write_employee(Employee a)
{
    fstream f;
    f.open("employee.oop",ios::out|ios::app);
    f.write(reinterpret_cast< char * >(&a),sizeof(a));
    f.close();
}

void read_employee()
{
    ifstream iff;
    iff.open("employee.oop",ios::in);
    Employee a;
    int j=0;
    while(iff.read((char *)(&a),sizeof(a)))
    {
        cout<<a;
    }
    iff.close();

}


#endif // EMPLOYEE_H_INCLUDED
