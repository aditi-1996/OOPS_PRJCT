#ifndef CUSTOMER_H_INCLUDED
#define CUSTOMER_H_INCLUDED

#include <fstream>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Person.h"

using namespace std;

class Customer;

int count_digit(long long n);

template<class T>
int Check_Customer(Customer &,T [],T []);

template<class T>
int Check_Customer(Customer &,T );

class Customer:public Person
{
    int c_id;
    Mobile *mob[5];
    static int n_mobile;
public:

    Customer(int id=0)
    {
        c_id=id;
        mob[0]=NULL;
        mob[1]=NULL;
        mob[2]=NULL;
        mob[3]=NULL;
        mob[4]=NULL;
    }

    char* get_name()
    {
        return name;
    }

    char* get_password()
    {
        return password;
    }

    int get_c_id()
    {
        return c_id;
    }

    void set_mobile(Mobile *m)
    {
        if (n_mobile < 5)
        {
            mob[n_mobile]=m;
            n_mobile++;
        }
    }


    void show()
    {
        cout<<name;
        cout<<password;
    }
    friend ostream &operator<<( ostream &, const Customer & );
    friend istream &operator>>( istream &, Customer & );
};

int Customer::n_mobile=0;

// overloaded stream extraction operator; cannot be
// a member function if we would like to invoke it with
// cin >> someCustomer;
istream &operator>>( istream &input, Customer &cust )
{
    cout<<"Enter Customer Details.....\n";
    cout<<"ID:";
    input >> cust.c_id;
    cout<<"Name:";
    input >> cust.name;
    cout<<"Password:";
    input >> cust.password;
    cout<<"Address:";
    input >> cust.add;
    cout<<"Email:";
    input >> cust.email;
    cout<<"Gender:";
    input >> cust.gender;
    int flag=0;
    while(flag!=1)
    {
        try
        {
            cout<<"Phone Number:";
            input >> cust.phn;
            int n=count_digit(cust.phn);
            if(n>10)
                throw cust.phn;
            else
                flag=1;
        }
        catch(...)
        {
            cout<<"!!! Invalid Number !!!\n";
            cout<<"No. of digits in your phone number "<<cust.phn<<" cannot be greater than ten\n";
        }
    }
    cout<<"Date Of Birth:";
    input >> cust.dob;
    cout<<"Age:";
    input >> cust.age;
    return input; // enables cin >> a >> b >> c;

} // end function operator>>


// overloaded stream insertion operator; cannot be
// a member function if we would like to invoke it with
// cout << someCustomer;
ostream &operator<<( ostream &output, const Customer &cust )
{
    cout<<"Customer Details.....\n";
    output << "ID:"<<cust.c_id<<"\n";
    output << "Name:"<<cust.name<<"\n";
    output << "Password:"<<cust.password<<"\n";
    output << "Address:"<<cust.add<<"\n";
    output << "Email:"<<cust.email<<"\n";
    output << "Gender:"<<cust.gender<<"\n";
    output << "Phone Number:"<<cust.phn<<"\n";
    output << "Date Of Birth:"<<cust.dob<<"\n";
    output << "Age:"<<cust.age<<"\n";
    return output;     // enables cout << a << b << c;

} // end function operator<<


void write_customer(Customer a)
{
    fstream f;
    f.open("customer.oop",ios::out|ios::app);
    f.write(reinterpret_cast< char * >(&a),sizeof(a));
    f.close();
}

void read_customer()
{
    ifstream iff;
    iff.open("customer.oop",ios::in);
    Customer a;
    int j=0;
    while(iff.read((char *)(&a),sizeof(a)))
    {
        cout<<a;
    }
    iff.close();

}

template<class T>
int Check_Customer(Customer &a,T name[],T password[])
{
    ifstream iff;
    try
    {
        iff.open("customer.oop",ios::in);
        if( !iff )
        {
            throw 1;
        }
        int j=0,flag=0;
        while(iff.read((char *)(&a),sizeof(a)))
        {
            if((strcmpi(name,a.get_name())==0)&&(strcmpi(password,a.get_password())==0))
            {
                flag=1;
                break;
            }
        }
        iff.close();
        if(flag==1)
        {
            return 1;
        }
        else
        {
          throw(name);
        }
    }
    catch(char *str)
    {
        cout<<"The Customer "<<str<<" doesn't exist in the database\n";
        return 0;
    }
    catch(int error)
    {
        cout << "!!! ERROR !!!\n";
        cout << "File could not be opened" << endl;
        return 0;
    }
}

template<class T>
int Check_Customer(Customer &a,T id)
{
    ifstream iff;
    try
    {
        iff.open("customer.oop",ios::in);
        if( !iff )
        {
            throw 1;
        }
        int j=0,flag=0;
        while(iff.read((char *)(&a),sizeof(a)))
        {
            if(id==a.get_c_id())
            {
                flag=1;
                break;
            }
        }
        iff.close();
        if(flag==1)
        {
            return 1;
        }
        else
        {
          throw("No Such Customer ID Exist");
        }
    }
    catch(int error)
    {
        cout << "!!! ERROR !!!\n";
        cout << "File could not be opened" << endl;
        return 0;
    }

    catch(...)
    {
        cout<<"No Such Customer ID Exist"<<"\n";
        return 0;
    }
}

int count_digit(long long n)
{
    int digit=0;
    while(n>0)
    {
        n=n/10;
        digit++;
    }
    return digit;
}

#endif // CUSTOMER_H_INCLUDED
