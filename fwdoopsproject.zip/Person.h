#ifndef PERSON_H_INCLUDED
#define PERSON_H_INCLUDED

#include <iostream>
#include <string.h>
#include <fstream>

using namespace std;

class Person
{
protected:

    char name[15];
    char gender[6];
    char password[15];
    char add[25];
    char email[5];
    long long phn;
    char dob[10];
    int age;

public:
    Person(char *n="",char *p="",char *a="",char *d="",char *e="",char *g="",long long ph=0000000000,int ag=0)
    {
        strcpy(name,n);
        strcpy(password,p);
        strcpy(add,a);
        strcpy(email,e);
        strcpy(dob,d);
        strcpy(gender,g);
        phn=ph;
        age=ag;

    }
    //static char* get_name()= 0;
    void show()
    {
        cout<<"adas";
    }
   // static char* get_password()=0;

};

class Mobile
{
    int m_id;
    int c_id;
    char imei[25];
    char model_no[25];
    long bill_no;

public:
    Mobile(int mid=0,int cid=0,char *im=" ",char *model="",long b=000000)
    {
        m_id=mid;
        c_id=cid;
        strcpy(imei,im);
        strcpy(model_no,model);
        bill_no=b;
    }
    void set_c_id(int id)
    {
        c_id=id;
    }

    friend ostream &operator<<( ostream &, const Mobile & );
    friend istream &operator>>( istream &, Mobile & );

};


// overloaded stream extraction operator; cannot be
// a member function if we would like to invoke it with
// cin >> someMobile;
istream &operator>>( istream &input, Mobile &mob )
{
    cout<<"Enter Mobile Details.....\n";
    cout<<"ID:";
    input >> mob.m_id;
    cout<<"IMEI:";
    input >> mob.imei;
    cout<<"Model Number:";
    input >> mob.model_no;
    cout<<"Bill Number";
    input >> mob.bill_no;
    return input; // enables cin >> a >> b >> c;

} // end function operator>>


// overloaded stream insertion operator; cannot be
// a member function if we would like to invoke it with
// cout << someMobile;
ostream &operator<<( ostream &output, const Mobile &mob )
{
    cout<<"Mobile Details.....\n";
    output << "Mobile ID:"<<mob.m_id<<"\n";
    output << "Customer ID:"<<mob.c_id<<"\n";
    output << "IMEI Number:"<<mob.imei<<"\n";
    output << "Model Number:"<<mob.model_no<<"\n";
    output << "Bill Number:"<<mob.bill_no<<"\n";
    return output;     // enables cout << a << b << c;

} // end function operator<<

void write_mobile(Mobile a)
{
    fstream f;
    f.open("mobile.oop",ios::out|ios::app);
    f.write(reinterpret_cast< char * >(&a),sizeof(a));
    f.close();
}

void read_mobile()
{
    ifstream iff;
    iff.open("mobile.oop",ios::in);
    Mobile a;
    int j=0;
    while(iff.read((char *)(&a),sizeof(a)))
    {
        cout<<a;
    }
    iff.close();

}

#endif // PERSON_H_INCLUDED
