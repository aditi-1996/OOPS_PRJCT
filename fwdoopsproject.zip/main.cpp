#include <iostream>
#include <string.h>
#include <typeinfo>
#include <cstdlib>
#include "Person.h"
#include "Employee.h"
#include "Customer.h"
#include "Department.h"


using namespace std;

void Customer_Register();
void Employee_Register();
void Employee_Login();
void Customer_Login();
int Check_Employee(Employee &);


template<class T>
void display(T a);

Consultant_Desk cd;
Repair_Desk rd;
Customer_Care cc;

int main()
{
 int n=1;
 char prompt;
 do
 {
    system("cls");
    cout<<"\nMAIN MENU"<<"\n";
    cout<<"1.Admin Login"<<"\n";
    cout<<"2.Customer Login"<<"\n";
    cout<<"3.Customer Register"<<"\n";
    cout<<"4.Employee Login"<<"\n";
    cout<<"5.Employee Register"<<"\n";
    cout<<"6.Exit"<<"\n";
    cout<<"Enter your choice:";
    int ch;
    cin>>ch;
    switch(ch)
    {
        case 1:
                break;

        case 2:Customer_Login();
                break;

        case 3:Customer_Register();
                break;

        case 4:Employee_Login();
                break;

        case 5:Employee_Register();
                break;

        case 6:n=0;
                break;

	    default:break;
     }
   cout<<"Press any key to continue";
   cin>>prompt;
   system("cls");
  }while(n!=0);

    //Employee a;
    //cin>>a;
    //write_customer(b);
    //read_customer();
    //write_employee(a);
    //read_employee();
    cout << "Hello world!" << endl;
    return 0;
}

void Customer_Register()
{
    Customer a;
    cin>>a;
    write_customer(a);
    read_customer();
}


void Employee_Register()
{
    Employee a;
    cin>>a;
    write_employee(a);
    cout<<"Department ID is.."<<a.get_d_id()<<"\n";
    switch(a.get_d_id())
    {
        case 1001:cd.insert_employee(&a);
                  break;


        case 1002:rd.insert_employee(&a);
                  break;

        case 1003:cc.insert_employee(&a);
                  break;

        case 1004://cd.insert_employee(&a);
                  break;


        case 1005://rd.insert_employee(&a);
                  break;

        case 1006://cc.insert_employee(&a);
                  break;


    }
    cout<<"cd"<<cd.get_n_emp()<<"\n";
    cout<<"rd"<<rd.get_n_emp()<<"\n";
    cout<<"cc"<<cc.get_n_emp()<<"\n";
    /*if(cd.get_n_emp()==1)
    {
        Employee *b=cd.get_emp();
        //cout<<*b;
        b->show();
    }*/
    //read_employee();
    display(a);
}

void Employee_Login()
{
    Employee a;
    if(Check_Employee(a))
    {
        switch(a.get_d_id())
        {
            case 1001:cd.add_mobile();
                  break;


            case 1002://rd.insert_employee(&a);
                  break;

            case 1003://cc.insert_employee(&a);
                  break;

            case 1004://cd.insert_employee(&a);
                  break;


            case 1005://rd.insert_employee(&a);
                  break;

            case 1006://cc.insert_employee(&a);
                  break;


        }
    }

}

int Check_Employee(Employee &a)
{
    ifstream iff;
    try
    {
        iff.open("employee.oop",ios::in);
        if( !iff )
        {
            throw 1;
        }
        int j=0,flag=0;
        char name[25],password[25];
        cout<<"Enter Employee Name:";
        cin>>name;
        cout<<"Enter Employee Password:";
        cin>>password;
        while(iff.read((char *)(&a),sizeof(a)))
        {
            if((strcmpi(name,a.get_name())==0)&&(strcmpi(password,a.get_password())==0))
            {
                flag=1;
                break;
            }
        }
        iff.close();
        if(flag==1)
        {
            cout<<a;
            return 1;
        }
        else
        {
          throw(name);
        }
    }
    catch(char *str)
    {
        cout<<"The Employee "<<str<<" doesn't exist in the database\n";
        return 0;
    }
    catch(int error)
    {
        cout << "!!! ERROR !!!\n";
        cout << "File could not be opened" << endl;
        return 0;
    }
}

void Customer_Login()
{
    Customer a;
    char name[25],password[25];
    cout<<"Enter Customer Name:";
    cin>>name;
    cout<<"Enter Customer Password:";
    cin>>password;
    if(Check_Customer(a,name,password))
        cout<<a;
}


template<class T>
void display(T a)
{
    cout<<a;
}
