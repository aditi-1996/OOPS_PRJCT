#ifndef DEPARTMENT_H_INCLUDED
#define DEPARTMENT_H_INCLUDED

#include <iostream>
#include <string.h>
#include "Employee.h"
#include "Customer.h"

using namespace std;

class Department
{
protected:

    Employee *emp[100];
    virtual void insert_employee(Employee *)=0;


};

class Consultant_Desk:public Department
{
    static int n_emp;

 public:

    void insert_employee(Employee *e)
    {
        if (n_emp < 100)
        {
            emp[n_emp]=e;
            ++n_emp;
        }
    }
    int get_n_emp()
    {
        return n_emp;
    }

    Employee* get_emp()
    {
        return emp[0];
    }

    void add_mobile()
    {
        int id;
        Customer a;
        cout<<"Enter the Customer ID:";
        cin>>id;
        if(Check_Customer(a,id))
        {
            cout<<a;
            Mobile m;
            cin>>m;
            m.set_c_id(id);
            write_mobile(m);
            read_mobile();
        }

    }
};

class Repair_Desk:public Department
{
    static int n_emp;

 public:

    void insert_employee(Employee *e)
    {
        if (n_emp < 100)
        {
            emp[n_emp]=e;
            ++n_emp;
        }
    }

    int get_n_emp()
    {
        return n_emp;
    }
};

class Customer_Care:public Department
{
    static int n_emp;

 public:

    void insert_employee(Employee *e)
    {
        if (n_emp < 100)
        {
            emp[n_emp]=e;
            ++n_emp;
        }
    }

    int get_n_emp()
    {
        return n_emp;
    }
};

class Collection_Desk:public Department
{
    static int n_emp;

 public:
    void insert_employee(Employee *e)
    {
        if (n_emp < 100)
        {
            emp[n_emp]=e;
            ++n_emp;
        }
    }

    int get_n_emp()
    {
        return n_emp;
    }
};

class Visitor_Desk:public Department
{
    static int n_emp;

 public:
    void insert_employee(Employee *e)
    {
        if (n_emp < 100)
        {
            emp[n_emp]=e;
            ++n_emp;
        }
    }

    int get_n_emp()
    {
        return n_emp;
    }
};


class Stock:public Department
{
    static int n_emp;

 public:
    void insert_employee(Employee *e)
    {
        if (n_emp < 100)
        {
            emp[n_emp]=e;
            ++n_emp;
        }
    }

    int get_n_emp()
    {
        return n_emp;
    }
};

int Consultant_Desk::n_emp=0;
int Repair_Desk::n_emp=0;
int Customer_Care::n_emp=0;
int Collection_Desk::n_emp=0;
int Visitor_Desk::n_emp=0;
int Stock::n_emp=0;


#endif // DEPARTMENT_H_INCLUDED
